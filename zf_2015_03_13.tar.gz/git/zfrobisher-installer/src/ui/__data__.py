from modules.i18n.i18n import _

#
# Menu
#
ROOT_PASSWORD = _('Root Password')
TIMEZONE_SELECTION = _('Timezone selection')
DATE_AND_TIME = _('Date and Time')
CONFIGURE_NETWORK = _('Configure Network')
DNS_CONFIGURATION = _('DNS configuration')
EXIT = _('Exit')
