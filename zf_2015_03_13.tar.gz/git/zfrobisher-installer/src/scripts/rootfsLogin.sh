#!/bin/sh

# Start installer
/bin/zkvm-installer
