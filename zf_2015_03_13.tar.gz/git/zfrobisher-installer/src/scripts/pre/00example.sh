#!/bin/sh -e

date  +"%Y%m%d-%H%M%S"
echo "00example.sh"

exit 0
